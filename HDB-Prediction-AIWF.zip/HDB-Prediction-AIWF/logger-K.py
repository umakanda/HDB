<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta http-equiv="Content-Style-Type" content="text/css">
  <title>AI-worflow/logger.py at master · biharicoder/AI-worflow</title>
  <meta name="Description" content="An End to end workflow for AI project including lots of  reusable templates - biharicoder/AI-worflow">
  <meta name="Generator" content="Cocoa HTML Writer">
  <meta name="CocoaVersion" content="1894.2">
  <style type="text/css">
    p.p1 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 14.0px; font: 12.0px Times; color: #000000; -webkit-text-stroke: #000000}
    p.p2 {margin: 0.0px 0.0px 12.0px 0.0px; line-height: 14.0px; font: 12.0px Times; color: #000000; -webkit-text-stroke: #000000}
    li.li3 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 14.0px; font: 12.0px Times; color: #000000}
    span.s1 {font-kerning: none}
    td.td1 {margin: 0.5px 0.5px 0.5px 0.5px; padding: 1.0px 1.0px 1.0px 1.0px}
    td.td2 {width: 473.0px; margin: 0.5px 0.5px 0.5px 0.5px; padding: 1.0px 1.0px 1.0px 1.0px}
    ul.ul1 {list-style-type: disc}
  </style>
</head>
<body>
<p class="p1"><span class="s1"><br>
</span></p>
<p class="p1"><span class="s1"><br>
</span></p>
<p class="p2"><span class="s1"><br>
</span></p>
<p class="p1"><span class="s1"><br>
</span></p>
<table cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">import time,os,re,csv,sys,uuid,joblib</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">from datetime import date</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">import numpy as np</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">from sklearn import svm</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">from sklearn import datasets</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">from sklearn.model_selection import train_test_split</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">from sklearn.metrics import classification_report</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">## model specific variables (iterate the version and note with each change)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">MODEL_VERSION = 0.1</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">MODEL_VERSION_NOTE = "example random forest on toy data"</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">SAVED_MODEL = "model-{}.joblib".format(re.sub("\.","_",str(MODEL_VERSION)))</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">def fetch_data():</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">example function to fetch data for training</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">## import some data to play with</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">iris = datasets.load_iris()</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">X = iris.data[:,:2]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">y = iris.target</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">return(X,y)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">def model_train(mode=None):</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">example funtion to train model</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">'mode' - can be used to subset data essentially simulating a train</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">## data ingestion</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">X,y = fetch_data()</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">## Perform a train-test split</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=42)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">## Specify parameters and model</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">params = {'C':1.0,'kernel':'linear','gamma':0.5}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">clf = svm.SVC(**params,probability=True)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">## fit model on training data</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">clf = clf.fit(X_train, y_train)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">y_pred = clf.predict(X_test)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">print(classification_report(y_test,y_pred))</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">## retrain using all data</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">clf.fit(X, y)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">print("... saving model: {}".format(SAVED_MODEL))</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">joblib.dump(clf,SAVED_MODEL)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">def model_load():</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">example funtion to load model</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">if not os.path.exists(SAVED_MODEL):</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">raise Exception("Model '{}' cannot be found did you train the model?".format(SAVED_MODEL))</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">model = joblib.load(SAVED_MODEL)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">return(model)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">def model_predict(query,model=None):</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">example funtion to predict from model</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">## start timer for runtime</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">time_start = time.time()</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">## load model if needed</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">if not model:</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">model = model_load()</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">## output checking</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">if len(query.shape) == 1:</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">query = query.reshape(1, -1)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">## make prediction and gather data for log entry</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">y_pred = model.predict(query)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">y_proba = None</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">if 'predict_proba' in dir(model) and model.probability == True:</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">y_proba = model.predict_proba(query)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">m, s = divmod(time.time()-time_start, 60)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">h, m = divmod(m, 60)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">runtime = "%03d:%02d:%02d"%(h, m, s)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">## update the log file</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">_update_predict_log(y_pred, y_proba, query, runtime)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">return({'y_pred':y_pred,'y_proba':y_proba})</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">if __name__ == "__main__":</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">basic test procedure for model.py</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">## train the model</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">model_train()</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">## load the model</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">model = model_load()</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">## example predict</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">for query in [np.array([[6.1,2.8]]), np.array([[7.7,2.5]]), np.array([[5.8,3.8]])]:</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">result = model_predict(query,model)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">y_pred = result['y_pred']</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p1"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p1"><span class="s1">print("predicted: {}".format(y_pred))</span></p>
      </td>
    </tr>
  </tbody>
</table>
<p class="p1"><span class="s1"><br>
</span></p>
<ul class="ul1">
  <li class="li3"></li>
</ul>
</body>
</html>
