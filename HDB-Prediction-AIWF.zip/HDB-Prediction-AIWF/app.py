<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta http-equiv="Content-Style-Type" content="text/css">
  <title>AI-worflow/app.py at master · biharicoder/AI-worflow</title>
  <meta name="Description" content="An End to end workflow for AI project including lots of  reusable templates - biharicoder/AI-worflow">
  <meta name="Generator" content="Cocoa HTML Writer">
  <meta name="CocoaVersion" content="1894.2">
  <style type="text/css">
    p.p1 {margin: 0.0px 0.0px 12.0px 0.0px; line-height: 14.0px; font: 12.0px Times; color: #000000; -webkit-text-stroke: #000000}
    p.p2 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 14.0px; font: 12.0px Times; color: #000000; -webkit-text-stroke: #000000}
    span.s1 {font-kerning: none}
    td.td1 {margin: 0.5px 0.5px 0.5px 0.5px; padding: 1.0px 1.0px 1.0px 1.0px}
    td.td2 {width: 541.3px; margin: 0.5px 0.5px 0.5px 0.5px; padding: 1.0px 1.0px 1.0px 1.0px}
  </style>
</head>
<body>
<p class="p1"><span class="s1"><br>
</span></p>
<p class="p2"><span class="s1"><br>
</span></p>
<table cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">from flask import Flask, jsonify, request, render_template, redirect</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">import joblib</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">import socket</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">import json</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">import pandas as pd</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">import os</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">import sys</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">import requests</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">from model import model_predict, model_train</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">app = Flask(__name__)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">@app.route("/")</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">def hello():</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">html = "&lt;h3&gt;Hello {name}!&lt;/h3&gt;" \</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">"&lt;b&gt;Hostname:&lt;/b&gt; {hostname}&lt;br/&gt;"</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">return html.format(name=os.getenv("NAME", "world"), hostname=socket.gethostname())<span class="Apple-converted-space"> </span></span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">@app.route('/train', methods=['GET'])</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">def my_form():</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">return render_template('training_data.html')</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">@app.route('/train', methods=['POST'])</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">def train():</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">text = request.form['text']</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">model_train(text)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">print("Model training completed!")</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">return (jsonify("Model training completed"))</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">@app.route('/predict', methods=['GET'])</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">def predict_form():</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">return render_template('predict.html')</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">@app.route('/predict', methods=['POST'])</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">def predict():</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">text = request.form["Date"]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">year = text.split('-')[0]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">month = text.split('-')[1]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">date = text.split('-')[2]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">country = request.form["Country"]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">prediction = model_predict(country, year, month, date)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">prediction_jsonify = prediction['y_pred'].tolist()[0]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">print('Ye Number hai-', prediction_jsonify)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">output_text = country+": Predicted Forecast for 30 day period on "+text+" is: "+str(round(prediction_jsonify, 2))</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">print("YE HONA HAI OUTPUT:", output_text)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"># return jsonify(prediction['y_pred'].tolist())</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"># return jsonify(prediction['y_pred'].tolist())</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">return jsonify(output_text)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">if __name__ == '__main__':</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">saved_model = 'models/sl-united_kingdom-0_1.joblib'</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">model = joblib.load(saved_model)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">app.run(host='0.0.0.0', port=8080,debug=True)</span></p>
      </td>
    </tr>
  </tbody>
</table>
</body>
</html>
