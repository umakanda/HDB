<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta http-equiv="Content-Style-Type" content="text/css">
  <title>AI-worflow/cslib.py at master · biharicoder/AI-worflow</title>
  <meta name="Description" content="An End to end workflow for AI project including lots of  reusable templates - biharicoder/AI-worflow">
  <meta name="Generator" content="Cocoa HTML Writer">
  <meta name="CocoaVersion" content="1894.2">
  <style type="text/css">
    p.p1 {margin: 0.0px 0.0px 12.0px 0.0px; line-height: 14.0px; font: 12.0px Times; color: #000000; -webkit-text-stroke: #000000}
    p.p2 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 14.0px; font: 12.0px Times; color: #000000; -webkit-text-stroke: #000000}
    li.li3 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 14.0px; font: 12.0px Times; color: #000000}
    span.s1 {font-kerning: none}
    td.td1 {margin: 0.5px 0.5px 0.5px 0.5px; padding: 1.0px 1.0px 1.0px 1.0px}
    td.td2 {width: 514.5px; margin: 0.5px 0.5px 0.5px 0.5px; padding: 1.0px 1.0px 1.0px 1.0px}
    ul.ul1 {list-style-type: disc}
  </style>
</head>
<body>
<p class="p1"><span class="s1"><br>
</span></p>
<p class="p2"><span class="s1"><br>
</span></p>
<table cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">#!/usr/bin/env python</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">collection of functions for the final case study solution</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">import os</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">import sys</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">import re</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">import shutil</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">import time</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">from datetime import datetime</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">import numpy as np</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">import pandas as pd</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">import matplotlib.pyplot as plt</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">import matplotlib.dates as mdates</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">from pandas.plotting import register_matplotlib_converters</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">register_matplotlib_converters()</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">COLORS = ["darkorange","royalblue","slategrey"]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">def fetch_data(data_dir):</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">laod all json formatted files into a dataframe</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">## input testing</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">if not os.path.isdir(data_dir):</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">raise Exception("specified data dir does not exist")</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">if not len(os.listdir(data_dir)) &gt; 0:</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">raise Exception("specified data dir does not contain any files")</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">file_list = [os.path.join(data_dir,f) for f in os.listdir(data_dir) if re.search("\.json",f)]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">correct_columns = ['country', 'customer_id', 'day', 'invoice', 'month',</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">'price', 'stream_id', 'times_viewed', 'year']</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">## read data into a temp structure</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">all_months = {}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">for file_name in file_list:</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">df = pd.read_json(file_name)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">all_months[os.path.split(file_name)[-1]] = df</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">## ensure the data are formatted with correct columns</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">for f,df in all_months.items():</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">cols = set(df.columns.tolist())</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">if 'StreamID' in cols:</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">df.rename(columns={'StreamID':'stream_id'},inplace=True)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">if 'TimesViewed' in cols:</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">df.rename(columns={'TimesViewed':'times_viewed'},inplace=True)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">if 'total_price' in cols:</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">df.rename(columns={'total_price':'price'},inplace=True)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">cols = df.columns.tolist()</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">if sorted(cols) != correct_columns:</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">raise Exception("columns name could not be matched to correct cols")</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">## concat all of the data</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">df = pd.concat(list(all_months.values()),sort=True)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">years,months,days = df['year'].values,df['month'].values,df['day'].values<span class="Apple-converted-space"> </span></span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">dates = ["{}-{}-{}".format(years[i],str(months[i]).zfill(2),str(days[i]).zfill(2)) for i in range(df.shape[0])]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">df['invoice_date'] = np.array(dates,dtype='datetime64[D]')</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">df['invoice'] = [re.sub("\D+","",i) for i in df['invoice'].values]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">## sort by date and reset the index</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">df.sort_values(by='invoice_date',inplace=True)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">df.reset_index(drop=True,inplace=True)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">return(df)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">def convert_to_ts(df_orig, country=None):</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">given the original DataFrame (fetch_data())</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">return a numerically indexed time-series DataFrame<span class="Apple-converted-space"> </span></span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">by aggregating over each day</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">if country:</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">if country not in np.unique(df_orig['country'].values):</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">raise Exception("country not found")</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">mask = df_orig['country'] == country</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">df = df_orig[mask]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">else:</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">df = df_orig</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">## use a date range to ensure all days are accounted for in the data</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">invoice_dates = df['invoice_date'].values</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">start_month = '{}-{}'.format(df['year'].values[0],str(df['month'].values[0]).zfill(2))</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">stop_month = '{}-{}'.format(df['year'].values[-1],str(df['month'].values[-1]).zfill(2))</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">df_dates = df['invoice_date'].values.astype('datetime64[D]')</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">days = np.arange(start_month,stop_month,dtype='datetime64[D]')</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">purchases = np.array([np.where(df_dates==day)[0].size for day in days])</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">invoices = [np.unique(df[df_dates==day]['invoice'].values).size for day in days]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">streams = [np.unique(df[df_dates==day]['stream_id'].values).size for day in days]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">views = [df[df_dates==day]['times_viewed'].values.sum() for day in days]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">revenue = [df[df_dates==day]['price'].values.sum() for day in days]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">year_month = ["-".join(re.split("-",str(day))[:2]) for day in days]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">df_time = pd.DataFrame({'date':days,</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">'purchases':purchases,</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">'unique_invoices':invoices,</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">'unique_streams':streams,</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">'total_views':views,</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">'year_month':year_month,</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">'revenue':revenue})</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">return(df_time)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">def fetch_ts(data_dir, clean=False):</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">convenience function to read in new data</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">uses csv to load quickly</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">use clean=True when you want to re-create the files</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">ts_data_dir = os.path.join(data_dir)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">if clean:</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">shutil.rmtree(ts_data_dir)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">if not os.path.exists(ts_data_dir):</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">os.mkdir(ts_data_dir)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"># ## if files have already been processed load them<span class="Apple-converted-space"> </span></span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"># if len(os.listdir(ts_data_dir)) &gt; 0:</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"># print("... loading ts data from files")</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"># return({re.sub("\.csv","",cf)[3:]:pd.read_csv(os.path.join(ts_data_dir,cf)) for cf in os.listdir(ts_data_dir)})</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">## get original data</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">print("... processing data for loading")</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">df = fetch_data(data_dir)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">## find the top ten countries (wrt revenue)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">table = pd.pivot_table(df,index='country',values="price",aggfunc='sum')</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">table.columns = ['total_revenue']</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">table.sort_values(by='total_revenue',inplace=True,ascending=False)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">top_ten_countries = np.array(list(table.index))[:10]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">file_list = [os.path.join(data_dir,f) for f in os.listdir(data_dir) if re.search("\.json",f)]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">countries = [os.path.join(data_dir,"ts-"+re.sub("\s+","_",c.lower()) + ".csv") for c in top_ten_countries]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">## load the data</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">dfs = {}</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">dfs['all'] = convert_to_ts(df)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">for country in top_ten_countries:</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">country_id = re.sub("\s+","_",country.lower())</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">file_name = os.path.join(data_dir,"ts-"+ country_id + ".csv")</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">dfs[country_id] = convert_to_ts(df,country=country)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">## save the data as csvs<span class="Apple-converted-space"> </span></span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">for key, item in dfs.items():</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">item.to_csv(os.path.join(ts_data_dir,"ts-"+key+".csv"),index=False)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">return(dfs)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">def engineer_features(df,training=True):</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">for any given day the target becomes the sum of the next days revenue</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">for that day we engineer several features that help predict the summed revenue</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">the 'training' flag will trim data that should not be used for training</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">when set to false all data will be returned</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">"""</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">## extract dates</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">dates = df['date'].values.copy()</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">dates = dates.astype('datetime64[D]')</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">## engineer some features</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">eng_features = defaultdict(list)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">previous =[7, 14, 28, 70] #[7, 14, 21, 28, 35, 42, 49, 56, 63, 70]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">y = np.zeros(dates.size)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">for d,day in enumerate(dates):</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">## use windows in time back from a specific date</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">for num in previous:</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">current = np.datetime64(day, 'D')<span class="Apple-converted-space"> </span></span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">prev = current - np.timedelta64(num, 'D')</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">mask = np.in1d(dates, np.arange(prev,current,dtype='datetime64[D]'))</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">eng_features["previous_{}".format(num)].append(df[mask]['revenue'].sum())</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">## get the target revenue<span class="Apple-converted-space"> </span></span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">plus_30 = current + np.timedelta64(30,'D')</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">mask = np.in1d(dates, np.arange(current,plus_30,dtype='datetime64[D]'))</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">y[d] = df[mask]['revenue'].sum()</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">## attempt to capture monthly trend with previous years data (if present)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">start_date = current - np.timedelta64(365,'D')</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">stop_date = plus_30 - np.timedelta64(365,'D')</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">mask = np.in1d(dates, np.arange(start_date,stop_date,dtype='datetime64[D]'))</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">eng_features['previous_year'].append(df[mask]['revenue'].sum())</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">## add some non-revenue features</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">minus_30 = current - np.timedelta64(30,'D')</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">mask = np.in1d(dates, np.arange(minus_30,current,dtype='datetime64[D]'))</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">eng_features['recent_invoices'].append(df[mask]['unique_invoices'].mean())</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">eng_features['recent_views'].append(df[mask]['total_views'].mean())</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">X = pd.DataFrame(eng_features)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">## combine features in to df and remove rows with all zeros</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">X.fillna(0,inplace=True)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">mask = X.sum(axis=1)&gt;0</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">X = X[mask]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">y = y[mask]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">dates = dates[mask]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">X.reset_index(drop=True, inplace=True)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">if training == True:</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">## remove the last 30 days (because the target is not reliable)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">mask = np.arange(X.shape[0]) &lt; np.arange(X.shape[0])[-30]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">X = X[mask]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">y = y[mask]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">dates = dates[mask]</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">X.reset_index(drop=True, inplace=True)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">return(X,y,dates)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">if __name__ == "__main__":</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">run_start = time.time()<span class="Apple-converted-space"> </span></span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">data_dir = "cs-train"</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">print("...fetching data")</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">ts_all = fetch_ts(data_dir,clean=False)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">m, s = divmod(time.time()-run_start,60)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">h, m = divmod(m, 60)</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">print("load time:", "%d:%02d:%02d"%(h, m, s))</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">for key,item in ts_all.items():</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">print(key,item.shape)</span></p>
      </td>
    </tr>
  </tbody>
</table>
<p class="p2"><span class="s1"><br>
</span></p>
<ul class="ul1">
  <li class="li3"></li>
</ul>
</body>
</html>
