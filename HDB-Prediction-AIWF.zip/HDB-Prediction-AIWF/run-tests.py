<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta http-equiv="Content-Style-Type" content="text/css">
  <title>AI-worflow/run-tests.py at master · biharicoder/AI-worflow</title>
  <meta name="Description" content="An End to end workflow for AI project including lots of  reusable templates - biharicoder/AI-worflow">
  <meta name="Generator" content="Cocoa HTML Writer">
  <meta name="CocoaVersion" content="1894.2">
  <style type="text/css">
    p.p1 {margin: 0.0px 0.0px 12.0px 0.0px; line-height: 14.0px; font: 12.0px Times; color: #000000; -webkit-text-stroke: #000000}
    p.p2 {margin: 0.0px 0.0px 0.0px 0.0px; line-height: 14.0px; font: 12.0px Times; color: #000000; -webkit-text-stroke: #000000}
    span.s1 {font-kerning: none}
    td.td1 {margin: 0.5px 0.5px 0.5px 0.5px; padding: 1.0px 1.0px 1.0px 1.0px}
    td.td2 {width: 110.3px; margin: 0.5px 0.5px 0.5px 0.5px; padding: 1.0px 1.0px 1.0px 1.0px}
  </style>
</head>
<body>
<p class="p1"><span class="s1"><br>
</span></p>
<p class="p2"><span class="s1"><br>
</span></p>
<table cellspacing="0" cellpadding="0">
  <tbody>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">#!/usr/bin/python<span class="Apple-converted-space"> </span></span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">import sys</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">import unittest</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">from unittests import *</span></p>
      </td>
    </tr>
    <tr>
      <td valign="middle" class="td1">
        <p class="p2"><span class="s1"><br>
</span></p>
      </td>
      <td valign="middle" class="td2">
        <p class="p2"><span class="s1">unittest.main()</span></p>
      </td>
    </tr>
  </tbody>
</table>
<p class="p2"><span class="s1"><br>
</span></p>
</body>
</html>
